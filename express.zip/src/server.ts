import express , {type Application, type Request, type Response} from "express";

const app : Application = express();
const port = 5000;

app.use(express.json());
app.use(express.text());

app.get("/" , (req:Request , res:Response ) => {
  // res.send('hello this is me ');
  res.status(200).json({
    success:true,
    message:"this is new sms",
    author:"PH"
  });

})

app.post("/" , async(req : Request , res : Response) => {
  const {name , age} = req.body;

   res.status(200).json({
    success:true,
    message:"this is new sms",
    data:{name , age}
  });

});


app.listen(port , () =>{
console.log(`server is on ${port}`);
});